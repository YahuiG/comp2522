

public class ArithmeticTable {
    
	private float[][] table;
	private int start;
    private int end;
    private TableType tableType;
    
    /* 
     * To avoid checkstyle error.
     *3 for argument length
     *100 for the biggest number for table row and columns
     *
     **/
    final int argumentLength = 3;
    final int maxNumber = 100;

    private enum TableType 
    { ADD, MULT}
   
    /**
     * This method creates 2d array for the multiplication or addition table.
     * @param begin the table's starting value.
     * @param finish the table's ending value.
     * @param tableType table type ADD or MULT.
     */
    	
    public void createTable(int begin, 
    						int finish, 
    						TableType tableType) 
    {
        this.start = begin;
        this.end = finish;
        this.tableType = tableType;
        int tableSize = finish - begin + 1;		//Length of table

        this.table = new float[tableSize][tableSize];

        if (tableType == TableType.ADD)
        {
            for (int i = 0; i < tableSize; i++) 
            {

                for (int j = 0; j < tableSize; j++) 
                {
                    this.table[i][j] = (start + i) + (start + j);		//addition table
                }
            }
        } 
        else 
        {
            for (int i = 0; i < tableSize; i++) 
            {
                for (int j = 0; j < tableSize; j++) 
                {
                    this.table[i][j] = (start + i) * (start + j);		//multiplication table
                }
            }
        }
    }

    /**
     * Prints the created table.
     */
    public void printTable() 
    {
        int length = end - start;
        int a = start;
        for (int i = 0; i <= length; i++) 
        {
            System.out.println();
            if (a == start) 
            {
                if (tableType == TableType.ADD) 
                {
                    System.out.print("+      ");
                } 
                else
                {
                    System.out.print("*      ");
                }
                for (int b = start; b <= end; b++) 
                {
                    System.out.printf("%5d", b);
                }
                
                System.out.println();
                System.out.print("        ");
                
                for (int c = start; c <= end; c++)
                {
                    System.out.print("-----");
                }
               
                System.out.println();
                a = 0;
            }


            for (int j = 0; j <= length; j++) 
            {
                if (j == 0) 
                {
                    System.out.printf("%5d", i + start);
                    System.out.print(" |");
                }
                
                System.out.printf("%5.0f", table[i][j]);
            }
        }

    }


    /**
     * parameter Checks.
     * 
     * @param args
     *            input arguments on command line.
     * @return if input is valid or not
     */

public boolean argumentCheck(String[] args){
    if(args.length!=3)
    {
      System.err.println("Usage: Main <type> <start> <stop>");
      System.err.println("\tWhere <type> is one of +, \"*\"");
      System.err.println("\tand <start> is between 1 and 100");
      System.err.println("\tand <stop> is between 1 and 100");
      System.err.println("\tand start < stop");
      return false;
    }        

    if(args[0].charAt(0) == '+')
      tableType = TableType.ADD;
    else
      tableType = TableType.MULT;
      int sta;
      int sto;

      try{
        sta = Integer.parseInt(args[1]);
        sto = Integer.parseInt(args[2]);
      }
      catch(NumberFormatException ex){
        System.err.println("Usage: Main <type> <start> <stop>");
        System.err.println("\tWhere <type> is one of +, \"*\"");
        System.err.println("\tand <start> is between 1 and 100");
        System.err.println("\tand <stop> is between 1 and 100");
        System.err.println("\tand start < stop");
        return false;
      }

      if((sta < 1 || sta > 100)||((sto < 1 || sto > 100))){
        System.err.println("Usage: Main <type> <start> <stop>");
        System.err.println("\tWhere <type> is one of +, \"*\"");
        System.err.println("\tand <start> is between 1 and 100");
        System.err.println("\tand <stop> is between 1 and 100");
        System.err.println("\tand start < stop");
        return false;
      }

      if(sta >= sto){
        System.err.println("Usage: Main <type> <start> <stop>");
        System.err.println("\tWhere <type> is one of +,\"*\"");
        System.err.println("\tand <start> is between 1 and 100");
        System.err.println("\tand <stop> is between 1 and 100");
        System.err.println("\tand start < stop");
        return false;
      }
      
    start = sta;
    end = sto;
    return true;
  }
  public static void main(String[] args){
    ArithmeticTable table = new ArithmeticTable();
    if (table.argumentCheck(args)){
      table.createTable(table.start, table.end, table.tableType);
      table.printTable();
    }
  }
}